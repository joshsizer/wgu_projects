Author Joshua Sizer
Student ID: 001216849

To run this program, execute main.py in a python 3 interpreter:

python3 main.py

The analysis and justification, as required by the rubric, is in the Word-document "project_analysis_for_submit.docx"